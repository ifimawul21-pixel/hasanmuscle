import React, { useState } from "react";

const MadMusclesUltimateBeast = () => {
  const [step, setStep] = useState(1);
  const [activeWorkoutDay, setActiveWorkoutDay] = useState(null);
  const [userData, setUserData] = useState({
    gender: "",
    fullName: "",
    age: "",
    height: "",
    weight: "",
    goal: "",
    duration: "",
    favoriteWorkout: [],
    favoriteFood: [],
    activity: "",
    multiplier: 1.2,
  });

  // --- MEGA DATABASE MAKANAN (50+ VARIATION) ---
  const megaFoodDB = {
    Chicken: [
      "150g Dada Ayam Bakar + 200g Nasi Merah",
      "150g Ayam Suwir Lemon + 150g Ubi Cilembu",
      "Sate Ayam Tanpa Lemak + Lontong Gandum",
    ],
    Beef: [
      "150g Steak Sapi Lean + 200g Kentang Panggang",
      "150g Tumis Sapi Paprika + Nasi Merah",
      "150g Burger Patty Homemade Sapi Lean + Salad",
    ],
    Fish: [
      "150g Salmon Panggang + 150g Quinoa",
      "150g Ikan Dory Steam + Nasi Merah",
      "150g Tuna Steak + Salad Alpukat & Bayam",
    ],
    Eggs: [
      "Omelet 4 Putih Telur + Jamur + 2 Roti Gandum",
      "3 Telur Rebus + Salad Jagung",
      "Scrambled Eggs + Alpukat + Toast Gandum",
    ],
    Tofu: [
      "200g Tahu Tempe Bakem + Nasi Singkong",
      "Pepes Tahu Jamur + Nasi Merah",
      "Steak Tempe + Saus Lada Hitam + Kentang",
    ],
  };

  // --- LOGIKA VALID AHLI (SPORT SCIENCE) ---
  const bmr =
    10 * userData.weight +
    6.25 * userData.height -
    5 * userData.age +
    (userData.gender === "male" ? 5 : -161);
  const maintenance = bmr * (userData.multiplier || 1.2);
  let targetCalories =
    userData.goal === "lose weight"
      ? maintenance - 500
      : userData.goal === "build muscle"
      ? maintenance + 300
      : maintenance;

  const proteinGram = Math.round(userData.weight * 2.2);
  const fatGram = Math.round((targetCalories * 0.25) / 9);
  const carbGram = Math.round(
    (targetCalories - proteinGram * 4 - fatGram * 9) / 4
  );

  const getMacrosPerMeal = (ratio) => ({
    p: Math.round(proteinGram * ratio),
    c: Math.round(carbGram * ratio),
    f: Math.round(fatGram * ratio),
  });

  // --- JADWAL LATIHAN 1 MINGGU FULL (PPL 2.0 - HYPERTROPHY VOLUME) ---
  const weeklyWorkouts = [
    {
      day: "Senin",
      title: "PUSH A (Chest Focus)",
      moves: [
        "Flat Bench Press: 4x8-10",
        "Overhead Press: 3x10-12",
        "Incline Fly: 3x12-15",
        "Tricep Pushdown: 4x12",
      ],
    },
    {
      day: "Selasa",
      title: "PULL A (Back Focus)",
      moves: [
        "Deadlift: 3x5-8",
        "Lat Pulldown Wide: 4x10-12",
        "Seated Row: 3x12",
        "Barbell Curl: 3x12",
      ],
    },
    {
      day: "Rabu",
      title: "LEGS A (Quad Focus)",
      moves: [
        "Barbell Squat: 4x8-10",
        "Leg Press: 3x12-15",
        "Leg Extension: 3x15",
        "Calf Raise: 4x20",
      ],
    },
    {
      day: "Kamis",
      title: "REST / RECOVERY",
      moves: ["Light Walking 45m", "Full Body Stretching"],
    },
    {
      day: "Jumat",
      title: "PUSH B (Shoulder Focus)",
      moves: [
        "Military Press: 4x8-10",
        "Incline DB Press: 3x10-12",
        "Lateral Raise: 4x15-20",
        "Skullcrusher: 3x12",
      ],
    },
    {
      day: "Sabtu",
      title: "PULL B (Width Focus)",
      moves: [
        "Weighted Pull Ups: 3xMax",
        "One Arm DB Row: 3x10-12",
        "Face Pulls: 4x15",
        "Hammer Curl: 3x12",
      ],
    },
    {
      day: "Minggu",
      title: "LEGS B (Posterior Focus)",
      moves: [
        "Romanian Deadlift: 4x10-12",
        "Leg Curl: 4x12-15",
        "Bulgarian Split Squat: 3x12",
        "Plank: 3x60s",
      ],
    },
  ];

  const getRandom = (arr) =>
    arr ? arr[Math.floor(Math.random() * arr.length)] : "Loading...";
  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);
  const toggleSelection = (field, value) => {
    const current = userData[field];
    setUserData({
      ...userData,
      [field]: current.includes(value)
        ? current.filter((item) => item !== value)
        : [...current, value],
    });
  };

  return (
    <div className="min-h-screen bg-[#080808] text-white font-sans antialiased pb-20 selection:bg-[#FF4500]">
      {/* HEADER */}
      <header className="flex items-center justify-between p-4 border-b border-gray-900 sticky top-0 bg-[#080808] z-50">
        <button
          onClick={prevStep}
          disabled={step === 1 || step === 7}
          className="disabled:opacity-0 transition-opacity"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M15 19l-7-7 7-7"
            />
          </svg>
        </button>
        <div className="flex items-center gap-1 font-black italic text-2xl tracking-tighter uppercase">
          MAD{" "}
          <span className="text-[10px] border border-[#FF4500] text-[#FF4500] px-1.5 py-0.5 not-italic tracking-normal ml-1 italic font-bold">
            MUSCLES
          </span>
        </div>
        <div className="w-6"></div>
      </header>

      {/* PROGRESS BAR */}
      <div className="w-full bg-gray-900 h-1">
        <div
          className="bg-[#FF4500] h-full transition-all duration-700"
          style={{ width: `${(step / 7) * 100}%` }}
        ></div>
      </div>

      <main className="max-w-md mx-auto p-6">
        {step < 7 && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h1 className="text-3xl font-black mb-8 text-center uppercase italic tracking-tighter">
              Step {step}
            </h1>

            {step === 1 && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setUserData({ ...userData, gender: "male" })}
                    className={`p-6 rounded-2xl bg-[#1A1A1A] border-2 transition-all ${
                      userData.gender === "male"
                        ? "border-[#FF4500]"
                        : "border-transparent"
                    }`}
                  >
                    MALE
                  </button>
                  <button
                    onClick={() =>
                      setUserData({ ...userData, gender: "female" })
                    }
                    className={`p-6 rounded-2xl bg-[#1A1A1A] border-2 transition-all ${
                      userData.gender === "female"
                        ? "border-[#FF4500]"
                        : "border-transparent"
                    }`}
                  >
                    FEMALE
                  </button>
                </div>
                <input
                  type="text"
                  placeholder="Full Name"
                  className="w-full bg-[#1A1A1A] border border-gray-800 rounded-xl p-4 outline-none focus:border-[#FF4500]"
                  onChange={(e) =>
                    setUserData({ ...userData, fullName: e.target.value })
                  }
                />
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="number"
                    placeholder="Age"
                    className="bg-[#1A1A1A] p-3 rounded-xl border border-gray-800"
                    onChange={(e) =>
                      setUserData({ ...userData, age: e.target.value })
                    }
                  />
                  <input
                    type="number"
                    placeholder="Cm"
                    className="bg-[#1A1A1A] p-3 rounded-xl border border-gray-800"
                    onChange={(e) =>
                      setUserData({ ...userData, height: e.target.value })
                    }
                  />
                  <input
                    type="number"
                    placeholder="Kg"
                    className="bg-[#1A1A1A] p-3 rounded-xl border border-gray-800"
                    onChange={(e) =>
                      setUserData({ ...userData, weight: e.target.value })
                    }
                  />
                </div>
              </div>
            )}

            {step === 6 && (
              <div className="space-y-4">
                {[
                  {
                    id: "low",
                    l: "Sedentary",
                    d: "Banyak duduk, kerja kantoran, dan sangat jarang berolahraga.",
                    m: 1.2,
                  },
                  {
                    id: "mod",
                    l: "Moderate",
                    d: "Olahraga intensitas sedang 3-5 kali seminggu, rutin bergerak aktif.",
                    m: 1.55,
                  },
                  {
                    id: "high",
                    l: "Active",
                    d: "Atlet atau pekerjaan fisik berat, olahraga intens 6-7 kali seminggu.",
                    m: 1.8,
                  },
                ].map((a) => (
                  <button
                    key={a.id}
                    onClick={() => {
                      setUserData({
                        ...userData,
                        activity: a.id,
                        multiplier: a.m,
                      });
                      nextStep();
                    }}
                    className="w-full p-6 bg-[#1A1A1A] rounded-2xl text-left border-2 border-transparent hover:border-[#FF4500] transition-all"
                  >
                    <h3 className="font-black italic text-xl text-[#FF4500] uppercase mb-1">
                      {a.l}
                    </h3>
                    <p className="text-xs text-gray-500 font-medium leading-tight">
                      {a.d}
                    </p>
                  </button>
                ))}
              </div>
            )}

            {/* Other Steps Mapping */}
            {(step === 2 || step === 3 || step === 4 || step === 5) && (
              <div className="space-y-4">
                {step === 2 &&
                  ["lose weight", "build muscle", "keep fit"].map((g) => (
                    <button
                      key={g}
                      onClick={() => {
                        setUserData({ ...userData, goal: g });
                        nextStep();
                      }}
                      className="w-full p-6 bg-[#1A1A1A] rounded-2xl text-left font-black border-2 border-transparent hover:border-[#FF4500] italic uppercase"
                    >
                      {g}
                    </button>
                  ))}
                {step === 3 &&
                  ["4 Weeks", "8 Weeks", "12 Weeks"].map((d) => (
                    <button
                      key={d}
                      onClick={() => {
                        setUserData({ ...userData, duration: d });
                        nextStep();
                      }}
                      className="w-full p-6 bg-[#1A1A1A] rounded-2xl font-black border-2 border-transparent hover:border-[#FF4500] italic uppercase"
                    >
                      {d}
                    </button>
                  ))}
                {step === 4 && (
                  <div className="grid grid-cols-2 gap-4">
                    {["Gym", "Home"].map((w) => (
                      <button
                        key={w}
                        onClick={() => toggleSelection("favoriteWorkout", w)}
                        className={`p-4 rounded-xl bg-[#1A1A1A] border-2 uppercase font-black italic ${
                          userData.favoriteWorkout.includes(w)
                            ? "border-[#FF4500]"
                            : "border-transparent"
                        }`}
                      >
                        {w}
                      </button>
                    ))}
                  </div>
                )}
                {step === 5 && (
                  <div className="grid grid-cols-2 gap-4">
                    {["Chicken", "Beef", "Fish", "Eggs", "Tofu"].map((f) => (
                      <button
                        key={f}
                        onClick={() => toggleSelection("favoriteFood", f)}
                        className={`p-4 rounded-xl bg-[#1A1A1A] border-2 uppercase font-black italic ${
                          userData.favoriteFood.includes(f)
                            ? "border-[#FF4500]"
                            : "border-transparent"
                        }`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {step !== 2 && step !== 3 && step !== 6 && (
              <button
                onClick={nextStep}
                disabled={step === 1 && !userData.fullName}
                className="w-full bg-[#FF4500] mt-10 py-4 rounded-xl font-black italic uppercase tracking-widest active:scale-95 transition-all"
              >
                CONTINUE
              </button>
            )}
          </div>
        )}

        {/* STEP 7: MASTER BEAST DASHBOARD */}
        {step === 7 && (
          <div className="animate-in zoom-in duration-700 pb-10">
            {/* Nutrition Card */}
            <div className="bg-[#1A1A1A] p-8 rounded-3xl border border-gray-800 text-center mb-8 shadow-2xl relative overflow-hidden">
              <h2 className="text-[#FF4500] font-black uppercase text-[10px] tracking-[0.4em] mb-2 italic">
                Scientific Goal Plan
              </h2>
              <h1 className="text-7xl font-black tracking-tighter">
                {Math.round(targetCalories)}
              </h1>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-[-5px]">
                Kcal / Day
              </p>
              <div className="grid grid-cols-3 gap-2 mt-8">
                <div className="bg-black/40 p-3 rounded-2xl border-b-2 border-blue-500 font-black">
                  <p className="text-[9px] text-gray-500 uppercase">Prot</p>
                  {proteinGram}g
                </div>
                <div className="bg-black/40 p-3 rounded-2xl border-b-2 border-green-500 font-black">
                  <p className="text-[9px] text-gray-500 uppercase">Carb</p>
                  {carbGram}g
                </div>
                <div className="bg-black/40 p-3 rounded-2xl border-b-2 border-yellow-500 font-black">
                  <p className="text-[9px] text-gray-500 uppercase">Fat</p>
                  {fatGram}g
                </div>
              </div>
            </div>

            {/* Meal Plan Generator With Precise Grammage */}
            <div className="mb-10">
              <h3 className="text-xl font-black mb-4 flex items-center gap-2 italic uppercase">
                <span className="w-2 h-6 bg-[#FF4500] rounded-sm skew-x-[-15deg]"></span>{" "}
                Daily Meal Plan
              </h3>
              <div className="space-y-4">
                {[
                  {
                    t: "Sarapan (08:00)",
                    r: 0.25,
                    m: "60g Oatmeal + 1 Telur + 1 Pisang",
                  },
                  {
                    t: "Makan Siang (13:00)",
                    r: 0.35,
                    m: `${
                      getRandom(megaFoodDB[userData.favoriteFood[0]]) ||
                      "150g Ayam"
                    } + 200g Nasi Merah`,
                  },
                  {
                    t: "Snack (16:00)",
                    r: 0.15,
                    m: "30g Kacang Almond / Whey Protein",
                  },
                  {
                    t: "Makan Malam (19:00)",
                    r: 0.25,
                    m: `${
                      getRandom(megaFoodDB[userData.favoriteFood[1]]) ||
                      "150g Ikan"
                    } + Ubi Jalar`,
                  },
                ].map((item, i) => {
                  const macro = getMacrosPerMeal(item.r);
                  return (
                    <div
                      key={i}
                      className="bg-[#1A1A1A] p-5 rounded-2xl border-l-4 border-[#FF4500] shadow-md"
                    >
                      <div className="flex justify-between items-start mb-1">
                        <p className="text-[10px] text-[#FF4500] font-black uppercase tracking-widest italic">
                          {item.t}
                        </p>
                        <p className="text-[10px] text-gray-500 font-mono italic">
                          {Math.round(targetCalories * item.r)} Kcal
                        </p>
                      </div>
                      <p className="font-bold text-gray-100 text-sm italic uppercase mb-2">
                        {item.m}
                      </p>
                      <div className="flex gap-4 text-[10px] font-black text-gray-500 border-t border-gray-800 pt-3">
                        <span className="border-r border-gray-800 pr-3 italic">
                          P: {macro.p}g
                        </span>
                        <span className="border-r border-gray-800 pr-3 italic">
                          C: {macro.c}g
                        </span>
                        <span className="italic">F: {macro.f}g</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 7-Day Interactive Hypertrophy Workout */}
            <div className="mb-10 text-sm">
              <h3 className="text-xl font-black mb-4 flex items-center gap-2 italic uppercase">
                <span className="w-2 h-6 bg-[#FF4500] rounded-sm skew-x-[-15deg]"></span>{" "}
                7-Day Training Program
              </h3>
              <div className="space-y-3">
                {weeklyWorkouts.map((workout, index) => (
                  <div
                    key={index}
                    className="overflow-hidden bg-[#1A1A1A] rounded-2xl border border-gray-800 transition-all"
                  >
                    <button
                      onClick={() =>
                        setActiveWorkoutDay(
                          activeWorkoutDay === index ? null : index
                        )
                      }
                      className="w-full flex items-center justify-between p-5 hover:bg-[#252525]"
                    >
                      <div className="flex items-center gap-4 text-left">
                        <div className="w-10 h-10 bg-[#FF4500] rounded-xl flex items-center justify-center font-black italic shadow-lg">
                          {index + 1}
                        </div>
                        <div>
                          <p className="text-[9px] text-gray-500 font-bold uppercase mb-0.5 tracking-widest">
                            {workout.day}
                          </p>
                          <h4 className="font-black italic uppercase text-xs tracking-tighter text-gray-200">
                            {workout.title}
                          </h4>
                        </div>
                      </div>
                      <svg
                        className={`w-5 h-5 transition-transform duration-300 ${
                          activeWorkoutDay === index
                            ? "rotate-180 text-[#FF4500]"
                            : ""
                        }`}
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M19 9l-7 7-7-7"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </button>
                    <div
                      className={`transition-all duration-300 ${
                        activeWorkoutDay === index
                          ? "max-h-80 p-5 pt-0 opacity-100"
                          : "max-h-0 opacity-0"
                      }`}
                    >
                      <div className="border-t border-gray-800 pt-4 space-y-2 text-gray-400 font-bold italic text-sm">
                        {workout.moves.map((m, i) => (
                          <div key={i} className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 bg-[#FF4500] rounded-full"></span>{" "}
                            {m}
                          </div>
                        ))}
                        <div className="mt-4 p-3 bg-black/40 rounded-xl border border-[#FF4500]/20 text-[10px] text-gray-400">
                          <span className="text-[#FF4500] font-black uppercase">
                            Note:
                          </span>{" "}
                          Gunakan prinsip Progressive Overload. Tambah beban
                          +2kg jika repetisi terasa ringan.
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => setStep(1)}
              className="w-full bg-white text-black font-black py-5 rounded-3xl text-lg hover:bg-gray-100 shadow-2xl tracking-widest italic uppercase"
            >
              RE-START ANALYSIS
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default MadMusclesUltimateBeast;
